#!/usr/bin/env python

import rospy
from new_exam_bolanos.msg import *

def listenerD():
	rospy.init_node('listenerD', anonymous = True)
	rospy.Subscriber("chatterC", TopicCB, NowLoadingD)
	rospy.spin()

def NowLoadingD(D1):
	talkerD_topic = rospy.Publisher('chatterD', TopicBD, queue_size = 20)
	rate = rospy.Rate(10)
	infoD = TopicBD()
	infoD.name = D1.name
	infoD.apellido = D1.apellido
	infoD.objeto = "coso"
	#rospy.loginfo("Hello %s %s",C1.name,infoC.apellido)
	talkerD_topic.publish(infoD)



if __name__ == '__main__':
	listenerD()
