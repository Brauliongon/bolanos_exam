#!/usr/bin/env python

import rospy
from new_exam_bolanos.msg import *
from new_exam_bolanos.srv import *

def talkerA3():
	talkerA3_topic = rospy.Publisher('chatterA3', TopicAC3, queue_size = 20)
	rospy.init_node('talkerA3', anonymous = True)
	rate = rospy.Rate(10)
	infoA3 = TopicAC3()
	infoA3.team = "le"
	while not rospy.is_shutdown():
		#rospy.loginfo("%s",infoA3.animal)
		talkerA3_topic.publish(infoA3)
		rospy.Subscriber("chatterB3", TopicBA3, NowLoadingA3)
		rate.sleep()

def NowLoadingA3(A3):
	talkerA3_n_topic = rospy.Publisher('chatterA3_n', TopicBA3, queue_size = 30)
	rate = rospy.Rate(10)
	infoA3_n = TopicBA3()
	infoA3_n.team = A3.team
	infoA3_n.win = A3.win
	infoA3_n.campeon = A3.campeon
	infoA3_n.when = A3.when
	#rospy.loginfo("Hello %s %s and your age is %s",A3.animal,A3.color, A3.pais)
	#talkerA3_n_topic.publish(infoA3_n)
	rospy.loginfo(Datos3_client(infoA3_n.team,A3.win,A3.when,A3.campeon))

def Datos3_client(a,b,c,d):
	rospy.wait_for_service('datos3')
	try:
		datos3 = rospy.ServiceProxy('datos3', data3)
		resp3 = datos3(a,b,c,d)
		return resp3.response3
	except rospy.ServiceException, e:
		print "Service call failed %s"%e

if __name__ == '__main__':
	try:
		talkerA3()
	except rospy.ROSInterruptException:
		pass
