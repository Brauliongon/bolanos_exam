#!/usr/bin/env python

import rospy
from new_exam_bolanos.msg import *
from new_exam_bolanos.srv import *

def talkerA():
	talkerA_topic = rospy.Publisher('chatterA', TopicAC, queue_size = 20)
	rospy.init_node('talkerA', anonymous = True)
	rate = rospy.Rate(10)
	infoA = TopicAC()
	infoA.name = "lazaro"
	while not rospy.is_shutdown():
		#rospy.loginfo("%s",infoA.name)
		talkerA_topic.publish(infoA)
		rospy.Subscriber("chatterB", TopicBA, NowLoadingA)
		rate.sleep()

def NowLoadingA(A1):
	talkerA_n_topic = rospy.Publisher('chatterA_n', TopicBA, queue_size = 20)
	rate = rospy.Rate(10)
	infoA_n = TopicBA()
	infoA_n.name = A1.name
	infoA_n.apellido = A1.apellido
	infoA_n.edad = A1.edad
	infoA_n.objeto = A1.objeto
	#rospy.loginfo("%s %s %s %s",A1.name,A1.apellido, A1.edad, A1.objeto)
	#talkerA_n_topic.publish(infoA_n)
	rospy.loginfo(Datos1_client(infoA_n.name,A1.apellido,A1.edad,A1.objeto))


def Datos1_client(a,b,c,d):
	rospy.wait_for_service('datos1')
	try:
		datos1 = rospy.ServiceProxy('datos1', data)
		resp1 = datos1(a,b,c,d)
		return resp1.response
	except rospy.ServiceException, e:
		print "Service call failed %s"%e

if __name__ == '__main__':
	try:
		talkerA()
	except rospy.ROSInterruptException:
		pass
