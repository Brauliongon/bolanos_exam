#!/usr/bin/env python

import rospy
from new_exam_bolanos.msg import *

def listenerC():
	rospy.init_node('listenerC', anonymous = True)
	rospy.Subscriber("chatterA", TopicAC, NowLoadingC)
	rospy.spin()



def NowLoadingC(C1):
	talkerC_topic = rospy.Publisher('chatterC', TopicCB, queue_size = 20)
	rate = rospy.Rate(10)
	infoC = TopicCB()
	infoC.name = C1.name
	infoC.apellido = "se"
	#rospy.loginfo("Hello %s %s",C1.name,infoC.apellido)
	talkerC_topic.publish(infoC)



if __name__ == '__main__':
	listenerC()
