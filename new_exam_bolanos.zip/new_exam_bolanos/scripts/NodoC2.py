#!/usr/bin/env python

import rospy
from new_exam_bolanos.msg import *

def listenerC2():
	rospy.init_node('listenerC2', anonymous = True)
	rospy.Subscriber("chatterA2", TopicAC2, NowLoadingC2)
	rospy.spin()



def NowLoadingC2(C2):
	talkerC2_topic = rospy.Publisher('chatterC2', TopicCB2, queue_size = 20)
	rate = rospy.Rate(10)
	infoC2 = TopicCB2()
	infoC2.animal = C2.animal
	infoC2.color = "y"
	#rospy.loginfo("Hello %s %s",C2.animal,infoC2.color)
	talkerC2_topic.publish(infoC2)



if __name__ == '__main__':
	listenerC2()
