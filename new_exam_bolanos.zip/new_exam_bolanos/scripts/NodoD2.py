#!/usr/bin/env python

import rospy
from new_exam_bolanos.msg import *

def listenerD2():
	rospy.init_node('listenerD2', anonymous = True)
	rospy.Subscriber("chatterC2", TopicBA2, NowLoadingD2)
	rospy.spin()



def NowLoadingD2(D2):
	talkerD2_topic = rospy.Publisher('chatterD2', TopicBD2, queue_size = 20)
	rate = rospy.Rate(10)
	infoD2 = TopicCB2()
	infoD2.animal = D2.animal
	infoD2.color = D2.color
	infoD2.comida = "pozole"
	#rospy.loginfo("Hello %s %s",D2.animal,infoD2.color)
	talkerD2_topic.publish(infoD2)



if __name__ == '__main__':
	listenerD2()
