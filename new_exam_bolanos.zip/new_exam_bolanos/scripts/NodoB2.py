#!/usr/bin/env python

import rospy
from new_exam_bolanos.msg import *

def listenerB2():
	rospy.init_node('listenerB2', anonymous = True)
	rospy.Subscriber("chatterD2", TopicCB2, NowLoadingB2)
	rospy.spin()



def NowLoadingB2(B2):
	talkerB2_topic = rospy.Publisher('chatterB2', TopicBA2, queue_size = 20)
	rate = rospy.Rate(10)
	infoB2 = TopicBA2()
	infoB2.animal = B2.animal
	infoB2.color = B2.color
	infoB2.comida = B2.comida
	infoB2.pais = "entera"
	#rospy.loginfo("Hello %s %s and you are from %s",B2.animal,B2.color, infoB2.pais)
	talkerB2_topic.publish(infoB2)



if __name__ == '__main__':
	listenerB2()
