#!/usr/bin/env python

import rospy
from new_exam_bolanos.msg import *

def listenerD3():
	rospy.init_node('listenerD3', anonymous = True)
	rospy.Subscriber("chatterC3", TopicCB3, NowLoadingD3)
	rospy.spin()

def NowLoadingD3(D3):
	talkerD3_topic = rospy.Publisher('chatterD3', TopicBD3, queue_size = 20)
	rate = rospy.Rate(10)
	infoD3 = TopicCB3()
	infoD3.team = D3.team
	infoD3.win = D3.win
	infoD3.campeon = "campeon"
	#rospy.loginfo("Hello %s %s",D3.animal,infoD3.color)
	talkerD3_topic.publish(infoD3)



if __name__ == '__main__':
	listenerD3()
