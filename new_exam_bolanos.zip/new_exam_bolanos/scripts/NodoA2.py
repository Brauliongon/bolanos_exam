#!/usr/bin/env python

import rospy
from new_exam_bolanos.msg import *
from new_exam_bolanos.srv import *

def talkerA2():
	talkerA2_topic = rospy.Publisher('chatterA2', TopicAC2, queue_size = 20)
	rospy.init_node('talkerA2', anonymous = True)
	rate = rospy.Rate(10)
	infoA2 = TopicAC2()
	infoA2.animal = "come"
	while not rospy.is_shutdown():
		#rospy.loginfo("%s",infoA2.animal)
		talkerA2_topic.publish(infoA2)
		rospy.Subscriber("chatterB2", TopicBA2, NowLoadingA2)
		rate.sleep()

def NowLoadingA2(A2):
	talkerA2_n_topic = rospy.Publisher('chatterA2_n', TopicBA2, queue_size = 20)
	rate = rospy.Rate(10)
	infoA2_n = TopicBA2()
	infoA2_n.animal = A2.animal
	infoA2_n.color = A2.color
	infoA2_n.pais = A2.pais
	infoA2_n.comida = A2.comida
	#rospy.loginfo("Hello %s %s and your age is %s",A2.animal,A2.color, A2.pais)
	#talkerA2_n_topic.publish(infoA2_n)
	rospy.loginfo(Datos2_client(infoA2_n.animal,A2.color,A2.pais,A2.comida))

def Datos2_client(a,b,c,d):
	rospy.wait_for_service('datos2')
	try:
		datos2 = rospy.ServiceProxy('datos2', data2)
		resp2 = datos2(a,b,c,d)
		return resp2.response2
	except rospy.ServiceException, e:
		print "Service call failed %s"%e

if __name__ == '__main__':
	try:
		talkerA2()
	except rospy.ROSInterruptException:
		pass
